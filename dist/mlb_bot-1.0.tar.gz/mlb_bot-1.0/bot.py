#!/usr/bin/env python3

# Global imports
import os, sys, pyautogui

# Local imports
from mlb_bot.util import hotkey_utils
from mlb_bot.util import logging_utils


def main():
    bot_hotkey = hotkey_utils.Hotkey(key_combination = '<ctrl>+l', activated_func = bot_run)
    bot_hotkey.run()

def bot_run():
    logging_utils.logpr("Running");

if __name__ == "__main__":
    print("\n")
    main()
    print("\n")
else:
    logging_utils.logpr(f"Only use \"{os.path.basename(__file__)}\" as a script!")
    sys.exit()

